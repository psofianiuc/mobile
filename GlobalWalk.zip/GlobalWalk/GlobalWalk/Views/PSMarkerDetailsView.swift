//
//  PSMarkerDetailsView.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 18/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit

class PSMarkerDetailsView: UIView {
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var markerImage: UIImageView!
    @IBOutlet var detailsTextField: UITextView!
    @IBOutlet var showMapButton: UIButton!
    
    var marker: Marker?
    
    func prepareWithMarker(_ marker: Marker) {
        self.marker = marker
        
        var title = ""
        if let characters = marker.title?.characters {
            for char in characters {
                title.append(String(char) + "\n")
            }
            titleLabel.text = title
        }
        
        dateLabel.text = App.getStringFromDate(marker.date)

        detailsTextField.text = marker.details ?? ""
        
        if let imageData = marker.photo as Data? {
            DispatchQueue.global(qos: .userInitiated).async {
                let image = UIImage(data: imageData)
                let rotatedImage = image?.imageRotatedByDegrees(degrees: 90, flip: false)
                DispatchQueue.main.async {
                    self.markerImage.image = rotatedImage
                }
            }
        }
        prepareUI()
    }
    
    func prepareUI() {
        self.markerImage.prepareGreenInterface()
        
        self.titleLabel.textColor = UIColor.white.withAlphaComponent(0.75)
        self.titleLabel.backgroundColor = Colors.basilGreen
        
        self.detailsTextField.layer.cornerRadius = 7
        self.detailsTextField.textColor = Colors.eggplant
        self.detailsTextField.backgroundColor = UIColor.white.withAlphaComponent(0.5)
        
        self.dateLabel.textColor = Colors.eggplant
        showMapButton.prepareGreenButtonWith(ButtonText.showMap)
    }
    
    @IBAction func showMapAction(_ sender: UIButton) {
        // TODO: Show map
        print("show map")
    }
    
}
