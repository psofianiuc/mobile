//
//  PSMarkerEditView.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 25/08/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit

class PSMarkerEditView: UIView {

    @IBOutlet var markerImage: UIImageView!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleTextField: UITextField!
    @IBOutlet var descriptionTextFiled: UITextField!
    @IBOutlet var saveButton: UIButton!
    
    var marker: Marker?
    weak var delegate: SaveProtocol?
    
    func prepareUI() {
        self.markerImage.prepareGreenInterface()
        self.saveButton.prepareGreenButtonWith(ButtonText.save)
    }
    
    func prepareWithMarker(_ marker: Marker) {
        self.marker = marker
        
        self.titleTextField.text = marker.title
        self.titleTextField.delegate = self
        self.descriptionTextFiled.text = marker.details
        self.descriptionTextFiled.delegate = self
        self.dateLabel.text = App.getStringFromDate(marker.date)
        
        if let imageData = marker.photo as Data? {
            DispatchQueue.global(qos: .userInitiated).async {
                let image = UIImage(data: imageData)
                let rotatedImage = image?.imageRotatedByDegrees(degrees: 90, flip: false)
                DispatchQueue.main.async {
                    self.markerImage.image = rotatedImage
                }
            }
        }
        
        self.prepareUI()
    }
    
    
    @IBAction func saveAction(_ sender: Any) {
        
        guard let marker = marker,
            let title = titleTextField.text,
            let details = descriptionTextFiled.text else {
            return
        }
        
        let error = CoreDataHelper.updateMarker(marker.id, title, details)
        delegate?.savedWithError(error)
    }
    
    func toggleButton() {
        var enabled = true

        if titleTextField.text == "" || descriptionTextFiled.text == "" {
            enabled = false
        }
        
        saveButton.isEnabled = enabled
        
    }
    
}

extension PSMarkerEditView: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        toggleButton()
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        toggleButton()
    }
    
    func textFieldDidChange( _ textField: UITextField?) {
        toggleButton()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let text = textField.text else { return true }
        let newLength = text.characters.count + string.characters.count - range.length
        if textField.tag == 1 {
            return newLength <= 15
        }
        return newLength <= 255
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.endEditing(true)
        return true
    }
    
}

