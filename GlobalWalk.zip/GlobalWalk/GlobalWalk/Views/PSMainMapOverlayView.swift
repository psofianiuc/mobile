//
//  PSMainMapOverlayView.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 14/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit

protocol MapOverlayProtocol: class {
    func changeMapToStyle(_ style: MapStyle)
    func dismissOverlayView()
    func dismissController()
    func stopLocationTracking()
    func startLocationTracking()
}

enum MapStyle {
    case normal
    case hybrid
    case terrain
    case satellit
    case none
}

class PSMainMapOverlayView: UIView {

    weak var delegate: MapOverlayProtocol?
    
    @IBOutlet var normalButton: UIButton!
    @IBOutlet var terrainButton: UIButton!
    @IBOutlet var satellitButton: UIButton!
    @IBOutlet var hybridButton: UIButton!
    
    @IBOutlet var hideMenuButton: UIButton!
    
    @IBOutlet var goBackButton: UIButton!
    @IBOutlet var locationTrackingButton: UIButton!
    
    var normalText: String
    var terrainText: String
    var satellitText: String
    var hybridText: String
    
    override init(frame: CGRect) {
        normalText = ""
        terrainText = ""
        satellitText = ""
        hybridText = ""
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        normalText = ""
        terrainText = ""
        satellitText = ""
        hybridText = ""
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        normalText = ""
        terrainText = ""
        satellitText = ""
        hybridText = ""
        prepareView()
    }
    
    func prepareView() {
        prepareButtons()
        
        normalText = normalButton.titleLabel?.text ?? ""
        terrainText = terrainButton.titleLabel?.text ?? ""
        satellitText = satellitButton.titleLabel?.text ?? ""
        hybridText = hybridButton.titleLabel?.text ?? ""
        
        self.backgroundColor =  UIColor(white: 1, alpha: 0.45)
    }
    
    private func prepareButtons() {
        normalButton.prepareWhiteButtonUIWith(ButtonText.optionNormal)
        terrainButton.prepareWhiteButtonUIWith(ButtonText.optionTerrain)
        satellitButton.prepareWhiteButtonUIWith(ButtonText.optionSatellit)
        hybridButton.prepareWhiteButtonUIWith(ButtonText.optionHybrid)
        hideMenuButton.prepareWhiteButtonUIWith(ButtonText.hideMapMenu)
        goBackButton.prepareWhiteButtonUIWith(ButtonText.goBackMapMenu)
        locationTrackingButton.prepareWhiteButtonUIWith(ButtonText.stopTracking)
    }
    
    @IBAction func changeMapStyle(_ sender: UIButton) {
        guard let title = sender.titleLabel?.text else {
            return
        }
        switch title {
        case normalText:
            delegate?.changeMapToStyle(.normal)
        case terrainText:
            delegate?.changeMapToStyle(.terrain)
        case satellitText:
            delegate?.changeMapToStyle(.satellit)
        case hybridText:
            delegate?.changeMapToStyle(.hybrid)
        default:
            delegate?.changeMapToStyle(.none)
        }
    }
    
    @IBAction func goBackAction(_ sender: UIButton) {
        delegate?.dismissController()
    }
    
    @IBAction func locationTrackingAction(_ sender: Any) {
        guard let locatingText = locationTrackingButton.titleLabel?.text else {
            return
        }
        switch locatingText {
        case ButtonText.stopTracking:
            locationTrackingButton.setTitle(ButtonText.startTracking, for: .normal)
            delegate?.stopLocationTracking()
        case ButtonText.startTracking:
            locationTrackingButton.setTitle(ButtonText.stopTracking, for: .normal)
            delegate?.startLocationTracking()
        default:
            break
        }
    }
    
    @IBAction func hideOptionsButton(_ sender: UIButton) {
        delegate?.dismissOverlayView()
    }
}
