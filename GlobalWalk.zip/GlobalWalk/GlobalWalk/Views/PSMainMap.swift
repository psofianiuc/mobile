//
//  PSMainMapVC.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 12/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit
import GoogleMaps
import CoreLocation

protocol PSMainMapProtocol: class {
    func showAlert(_ alert: UIAlertController)
    func showOptions()
}

class PSMainMap: UIView {
    
    var mapView: GMSMapView!
    let marker = GMSMarker()
    var locManager: CLLocationManager!
    weak var delegate: PSMainMapProtocol?
    
    var markersData = CoreDataHelper.getSavedMarkers()
    var markers = [GMSMarker]()
    
    let optionsButton = UIButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        locManager = CLLocationManager()
        locManager.delegate = self
        self.requestEnableLocalization()
        locManager.startUpdatingLocation()
        
        self.mapView = GMSMapView(frame: frame)
        marker.map = mapView
        self.addSubview(mapView)
        
        self.configureButton()
        self.updateLocation()
        self.createMarkers()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    private func configureButton() {
        let buttonFrame = CGRect(x: 25, y: 50, width: self.frame.width-50, height: 45)
        optionsButton.frame = buttonFrame
        optionsButton.prepareWhiteButtonUIWith(ButtonText.showMapMenu)
        self.addSubview(optionsButton)
        
        optionsButton.addTarget(self, action: #selector(PSMainMap.showOptions(_:)), for: .touchUpInside)
    }
    
    func showAccesDeniedAlert() {
        let alertController = UIAlertController (title: "Localization denied", message: "The app needs localization to be allowed.", preferredStyle: .alert)
        let settingsAction = UIAlertAction(title: "Settings", style: .default) { (_) -> Void in
            App.goToSettings()
        }
        alertController.addAction(settingsAction)
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alertController.addAction(cancelAction)
        
        delegate?.showAlert(alertController)
    }
    
    func checkLocationAuthorizationStatus() {
        self.changeForAuthorizationStatus(CLLocationManager.authorizationStatus())
    }
    
    @objc private func showOptions(_ sender: UIButton?) {
        delegate?.showOptions()
    }
    
    private func createMarkers() {
        DispatchQueue.global(qos: .userInitiated).async {
            for m in self.markersData {
                let mapMarker = GMSMarker()
                mapMarker.position = CLLocationCoordinate2D(latitude: CLLocationDegrees(m.latitude), longitude: CLLocationDegrees(m.longitude))
                mapMarker.map = self.mapView
                DispatchQueue.main.async {
                    self.markers.append(mapMarker)
                }
            }
        }
    }
}

extension PSMainMap: CLLocationManagerDelegate {

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        self.updateLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        self.changeForAuthorizationStatus(status)
    }
    
    func checkAuthorizationStatus() {
        self.changeForAuthorizationStatus(CLLocationManager.authorizationStatus())
    }
    
    func changeForAuthorizationStatus(_ status: CLAuthorizationStatus) {
        switch status {
        case .notDetermined:
            self.requestEnableLocalization()
        case .authorizedAlways, .authorizedWhenInUse:
            self.updateLocation()
        default:
            self.showAccesDeniedAlert()
        }
    }
    
    func locatingCondition() -> Bool {
        return CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse ||
            CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways
    }
    
    func requestEnableLocalization() {
        locManager.requestAlwaysAuthorization()
    }
    
    func updateLocation() {
        if (self.locatingCondition()){
            guard let currentLocation = locManager.location else {
                return
            }
            self.marker.position = currentLocation.coordinate
            self.mapView.animate(to: GMSCameraPosition.camera(withLatitude: currentLocation.coordinate.latitude, longitude: currentLocation.coordinate.longitude, zoom: 17))
        }
    }
}

extension PSMainMap {
    
    func changeMapToStyle(_ style: MapStyle) {
        switch style {
        case .normal:
            mapView.mapType = .normal
        case .hybrid:
            mapView.mapType = .hybrid
        case .satellit:
            mapView.mapType = .satellite
        case .terrain:
            mapView.mapType = .terrain
        default:
            mapView.mapType = .none
        }
    }
    
    func showOptionsButton() {
        self.optionsButton.isHidden = false
    }
    
    func hideOptionsButton() {
        self.optionsButton.isHidden = true
    }
    
    func stopTracking() {
        self.locManager.stopUpdatingLocation()
        self.marker.position = CLLocationCoordinate2D(latitude: 0, longitude: 0)
    }
    
    func startTracking() {
        self.locManager.startUpdatingLocation()
        self.updateLocation()
    }
}
