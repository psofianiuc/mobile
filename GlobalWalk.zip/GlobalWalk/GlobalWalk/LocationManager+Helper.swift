//
//  LocationManager+Helper.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 17/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import Foundation
import CoreLocation

class LocationHelper {
    class func locatingCondition() -> Bool {
        return CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse ||
            CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways
    }
    
    class func getCurrentLocation() -> [String: Float] {
        if locatingCondition() {
            let locManager = CLLocationManager()
            guard let currentLocation = locManager.location else {
                return [String: Float]()
            }
            return [Location.lat: Float(currentLocation.coordinate.latitude),
                    Location.long: Float(currentLocation.coordinate.longitude),
                    Location.alt: Float(currentLocation.altitude)]
        }
        return [String: Float]()
    }
    
    class func requestAlwaysAccess() {
        CLLocationManager().requestAlwaysAuthorization()
    }
}
