//
//  PSMapViewController.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 12/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit
import GoogleMaps
import CoreLocation

class PSMapViewController: UIViewController {

    var mapView: PSMainMap!
    var mapOverLayView: PSMainMapOverlayView?
    private var notification: NSObjectProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView = PSMainMap(frame: self.view.frame)
        view.addSubview(mapView)
        mapView.delegate = self
        self.configureMapOverlay()
        notification = NotificationCenter.default.addObserver(forName: .UIApplicationWillEnterForeground, object: nil, queue: .main) {
            [unowned self] notification in
            self.mapView.checkLocationAuthorizationStatus()
        }
    }
    
    func configureMapOverlay() {
        // This fails if used the method .fromNib()
        if let mapOverlay = Bundle.main.loadNibNamed(XibName.mainMapOverlay, owner: self, options: nil)?[0] as? PSMainMapOverlayView {
            self.mapOverLayView = mapOverlay
            self.mapOverLayView?.delegate = self
            self.mapOverLayView?.prepareView()
            if let view = self.mapOverLayView {
                self.view.addSubview(view)
            }
            self.mapOverLayView?.isHidden = true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
               self.mapView.checkLocationAuthorizationStatus()
    }
    
    deinit {
        if let notification = notification {
            NotificationCenter.default.removeObserver(notification)
        }
    }
    
    
}

extension PSMapViewController: PSMainMapProtocol {
    func showAlert(_ alert: UIAlertController) {
        present(alert, animated: true, completion: nil)
    }
    
    func showOptions() {
        self.mapOverLayView?.isHidden = false
        self.mapView.hideOptionsButton()
    }
}

extension PSMapViewController: MapOverlayProtocol {
    func changeMapToStyle(_ style: MapStyle) {
        self.mapView.changeMapToStyle(style)
    }
    
    func dismissOverlayView(){
        self.mapOverLayView?.isHidden = true
        self.mapView.showOptionsButton()
    }
    
    func dismissController() {
        self.dismiss(animated: true) { 
            
        }
    }
    
    func stopLocationTracking() {
        self.mapView.stopTracking()
        
    }
    
    func startLocationTracking() {
        self.mapView.startTracking()
    }
}

