//
//  PSBaseViewController.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 28/08/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit

protocol SaveProtocol: class {
    func savedWithError(_ error: CoreDataErrors)
}

class PSBaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.addKeyboardObservers()
    }
    
    deinit {
        self.removeKeyboardObservers()
    }
    
    override func loadView() {
        super.loadView()
    }
    
    func reloadData() {
        
    }

}

extension PSBaseViewController: SaveProtocol {
    
    func savedWithError(_ error: CoreDataErrors) {
        var alertTitle = Alert.error
        var alertMessage = ""
        
        switch error {
        case .noError:
            alertTitle = Alert.success
        case .markerNotExist:
            alertMessage = Alert.markerNotExists
        case .internalError:
            alertMessage = Alert.internalError
        case .propertyError:
            alertMessage = Alert.propertyMissing
        }
        
        let alertController = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: .alert)
        let okAction = UIAlertAction(title: Text.ok, style: .cancel, handler: nil)
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
}
