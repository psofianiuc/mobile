//
//  PSCameraViewController.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 14/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit

class PSCameraViewController: UIViewController, UINavigationControllerDelegate {
    
    let imagePicker = UIImagePickerController()
    var image: UIImage?
    var imageData: Data?
    var currentDate: Date?
    
    @IBOutlet var showCameraButton: UIButton!
    @IBOutlet var takenImageView: UIImageView!
    @IBOutlet var saveLocationButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePicker.delegate = self
        imagePicker.sourceType = .camera
        imagePicker.cameraCaptureMode = .photo
        imagePicker.allowsEditing = false
        imagePicker.modalPresentationStyle = .popover
        
        prepareUI()
    }
    
    private func prepareUI() {
        prepareButtons()
        prepareImageView()
    }
    
    private func prepareButtons() {
        showCameraButton.prepareWhiteButtonUIWith(ButtonText.openCamera)
        saveLocationButton.prepareWhiteButtonUIWith(ButtonText.saveLocation)
    }

    private func prepareImageView() {
        takenImageView.layer.borderColor = UIColor.black.cgColor
        takenImageView.layer.borderWidth = 2
    }
    
    private func showNoCameraAccessAlert() {
        let alertController = UIAlertController (title: "Camera denied", message: "The app needs camera to be allowed.", preferredStyle: .alert)
        let settingsAction = UIAlertAction(title: "Settings", style: .default) { (_) -> Void in
            App.goToSettings()
        }
        alertController.addAction(settingsAction)
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alertController.addAction(cancelAction)
    }
    
    // MARK: Button action
    
    @IBAction func showCameraAction(_ sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            self.present(imagePicker, animated: true, completion: nil)
        } else {
            self.showNoCameraAccessAlert()
        }
    }
    
    
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else {
            return
        }
        switch identifier {
        case SegueNames.saveLocation:
            let vc = segue.destination as? PSSaveLocationViewController
            vc?.imageData = imageData
            vc?.currentDate = currentDate
        default:
            break
        }
        
     }
 
}

extension PSCameraViewController: UIImagePickerControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        imagePicker.dismiss(animated: true, completion: nil)
        
        var pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage
        if pickedImage == nil {
            pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage
        }
        if pickedImage == nil {
            pickedImage = info[UIImagePickerControllerCropRect] as? UIImage
        }
        
        guard let newImage = pickedImage else {
            return
        }
        
        image = newImage
        takenImageView.image = image
        imageData = UIImagePNGRepresentation(newImage)
        currentDate = Date(timeIntervalSinceNow: 0)
    }
}
