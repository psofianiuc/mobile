//
//  PSAllMarkersViewController.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 18/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit

class PSAllMarkersViewController: PSBaseViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {

    @IBOutlet var collectionView: UICollectionView!
    @IBOutlet var backgroundLayerView: UIView!
    var allMarkers = CoreDataHelper.getSavedMarkers()
    let presenterVC = UIViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let markerNib = UINib(nibName: XibName.markerCollectionCell, bundle: nil)
        collectionView?.register(markerNib, forCellWithReuseIdentifier: CellIdentifier.markerCollectionCell)
        collectionView.delegate = self
        collectionView.dataSource = self
        self.automaticallyAdjustsScrollViewInsets = false
        prepareUI()
        refreshData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.refreshData()
    }
    
    override func reloadData() {
        self.refreshData()
    }
    
    private func prepareUI() {
        backgroundLayerView.backgroundColor = UIColor.white.withAlphaComponent(0.75)
        self.view.backgroundColor = Colors.springGreen
        self.collectionView.backgroundColor = .clear
    }
    
    // MARK: UICollectionViewDataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return allMarkers.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.markerCollectionCell, for: indexPath) as! PSMarkerCollectionViewCell
        
        cell.marker = allMarkers[indexPath.row]
        cell.delegate = self
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let marker = allMarkers[indexPath.row]
        if let view = self.getDetailsView(marker) {
            presenterVC.view = view
            presenterVC.hideKeyboardWhenTappedAround()
            navigationController?.pushViewController(presenterVC, animated: true)
        }
        
    }
    
    private func getDetailsView(_ marker: Marker) -> PSMarkerDetailsView? {
        if let detailsView: PSMarkerDetailsView = PSMarkerDetailsView.fromNib() {
            detailsView.prepareWithMarker(marker)
            return detailsView
        }
        return nil
    }
    
    // MARK: Private func
    
    private func refreshData() {
        allMarkers = CoreDataHelper.getSavedMarkers()
        collectionView?.reloadData()
    }
}
