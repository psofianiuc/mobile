//
//  PSMainMenuViewController.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 14/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class PSMainMenuViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func logOutAction(_ sender: Any) {
        do {
            try Auth.auth().signOut()
            UIApplication.shared.keyWindow?.rootViewController = GUIHelper.shared.getRootViewController()
            
        } catch {
            let alertController = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
}
