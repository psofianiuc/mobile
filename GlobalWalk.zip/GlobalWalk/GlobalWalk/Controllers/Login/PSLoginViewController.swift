//
//  PSLoginViewController.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 02/11/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class PSLoginViewController: UIViewController {
    @IBOutlet var titleLable: UILabel!
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        prepareUI()
    }
    
    // MARK: Private methods
    
    private func prepareUI() {
        passwordTextField.isSecureTextEntry = true

    }

    // MARK: Button actions
    
    @IBAction func loginAction(_ sender: UIButton) {
        if self.emailTextField.text == "" || self.passwordTextField.text == "" {
            
            let alertController = UIAlertController(title: "Error", message: "Please enter an email and password.", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            self.present(alertController, animated: true, completion: nil)
            
        } else {
            Auth.auth().signIn(withEmail: self.emailTextField.text!, password: self.passwordTextField.text!) { (user, error) in
                if error == nil {
                    print("You have successfully logged in")

                    let nextViewController = GUIHelper.shared.getRootViewController()
                    self.present(nextViewController, animated: true, completion: nil)
                    
                } else {
                    let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
    }
    
    @IBAction func registerAction(_ sender: UIButton) {
        let registerViewController = PSRegisterViewController.fromNib() as PSRegisterViewController
        self.show(registerViewController, sender: nil)
    }
    
    @IBAction func resetPasswordAction(_ sender: Any) {
        let resetPasswordViewController = PSRegisterViewController.fromNib() as PSResetPasswordViewController
        self.show(resetPasswordViewController, sender: nil)
    }
    
}

extension PSLoginViewController: UITextFieldDelegate {
    
}
