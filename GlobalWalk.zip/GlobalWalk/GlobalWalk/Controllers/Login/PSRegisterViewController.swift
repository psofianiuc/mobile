//
//  PSRegisterViewController.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 02/11/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class PSRegisterViewController: UIViewController {
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var retypePaswwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        prepareUI()
    }
    
    // MARK: Private methods
    
    private func prepareUI() {
        passwordTextField.isSecureTextEntry = true
        retypePaswwordTextField.isSecureTextEntry = true
    }
    
    private func submitUser() {
        Auth.auth().createUser(withEmail: emailTextField.text!, password: passwordTextField.text!) { (user, error) in
            
            if error == nil {
                print("You have successfully signed up")
                
                let nextViewController = GUIHelper.shared.getRootViewController()
                self.present(nextViewController, animated: true, completion: nil)
                
            } else {
                let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                
                let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(defaultAction)
                
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
    
    // MARK: Button actions

    @IBAction func submitAction(_ sender: Any) {
        if emailTextField.text == "" {
            let alertController = UIAlertController(title: "Error", message: "Please enter your email and password", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            present(alertController, animated: true, completion: nil)
            
        } else if passwordTextField.text != retypePaswwordTextField.text {
            let alertController = UIAlertController(title: "Error", message: "Not the same password", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            present(alertController, animated: true, completion: nil)
            
        } else {
            submitUser()
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: true) {
            
        }
    }
}
