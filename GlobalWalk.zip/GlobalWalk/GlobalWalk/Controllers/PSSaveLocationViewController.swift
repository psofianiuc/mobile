//
//  PSSaveLocationViewController.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 17/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit

class PSSaveLocationViewController: PSBaseViewController {
    
    var imageData: Data?
    var currentDate: Date?
    let currentLocation = LocationHelper.getCurrentLocation()

    @IBOutlet var saveLocationTitle: UILabel!
    @IBOutlet var titleTextField: UITextField!
    @IBOutlet var detailsTextField: UITextField!
    @IBOutlet var saveButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        self.removeKeyboardObservers()
        toggleButton()
        prepareUI()
        titleTextField.delegate = self
        titleTextField.tag = 1
        detailsTextField.delegate = self
        detailsTextField.tag = 2
    }
    
    private func prepareUI() {
        prepareButton()
        prepareLabel()
    }
    
    private func prepareButton() {
        saveButton.prepareWhiteButtonUIWith(ButtonText.save)
    }
    
    private func prepareLabel() {
        saveLocationTitle.text = ButtonText.saveLocation
    }
    
    @IBAction func saveAction(_ sender: UIButton) {
        guard let image = imageData, let date = currentDate, let title = titleTextField.text, let details = detailsTextField.text else {
            return
        }
        let error = CoreDataHelper.saveMarker(title, details,  currentLocation[Location.long],  currentLocation[Location.lat],  currentLocation[Location.alt], image, date)
        
        switch error {
        case .noError:
            self.navigationController?.popViewController(animated: true)
        default:
            self.savedWithError(error)
        }
    }
    
    func toggleButton() {
        var enabled = true
        if imageData == nil || currentDate == nil {
            enabled = false
        }
        if titleTextField.text == "" || detailsTextField.text == "" {
            enabled = false
        }
        if currentLocation.count == 0 {
            enabled = false
        }
        
        saveButton.isEnabled = enabled
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension PSSaveLocationViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        toggleButton()
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        toggleButton()
    }
    
    func textFieldDidChange( _ textField: UITextField?) {
        toggleButton()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let text = textField.text else { return true }
        let newLength = text.characters.count + string.characters.count - range.length
        if textField.tag == 1 {
            return newLength <= 15
        }
        return newLength <= 255
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
}
