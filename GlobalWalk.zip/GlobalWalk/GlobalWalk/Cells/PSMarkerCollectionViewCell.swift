//
//  PSMarkerCollectionViewCell.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 18/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit

class PSMarkerCollectionViewCell: UICollectionViewCell {
    @IBOutlet var markerImage: UIImageView!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var detailsTextField: UITextView!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var backgroundLayerView: UIView!
    @IBOutlet var moreButton: UIButton!
    
    weak var delegate: PSBaseViewController?
    
    var marker: Marker? {
        didSet {
            prepareForMarker()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        prepareCell()
    }
    
    override func prepareForReuse() {
        markerImage.image = nil
        titleLabel.text = ""
        dateLabel.text = ""
        detailsTextField.text = ""
    }
    
    private func prepareForMarker() {
        guard let marker = marker else {
            return
        }
        if let imageData = marker.photo as Data? {
            DispatchQueue.global(qos: .userInitiated).async {
                let image = UIImage(data: imageData)
                let rotatedImage = image?.imageRotatedByDegrees(degrees: 90, flip: false)
                DispatchQueue.main.async {
                    self.markerImage.image = rotatedImage
                }
            }
        }
        titleLabel.text = marker.title
        detailsTextField.text = marker.details
        dateLabel.text = App.getStringFromDate(marker.date)
    }
    
    private func prepareCell() {
        self.layer.cornerRadius = 7
        self.layer.borderWidth = 1
        self.layer.borderColor = Colors.basilGreen.cgColor
        
        self.backgroundColor = .white
        self.backgroundLayerView.backgroundColor = UIColor.white.withAlphaComponent(0.5)
        self.backgroundLayerView.clipsToBounds = true
        self.clipsToBounds = true
        
        self.titleLabel.textColor = UIColor.white.withAlphaComponent(0.75)
        self.titleLabel.backgroundColor = Colors.basilGreen
        
        self.detailsTextField.layer.cornerRadius = 7
        self.detailsTextField.textColor = Colors.eggplant
        self.detailsTextField.backgroundColor = UIColor.white.withAlphaComponent(0.5)
        
        self.dateLabel.textColor = Colors.eggplant
        
        self.markerImage.prepareGreenInterface()
    }
    
    @IBAction func moreButtonAction(_ sender: Any) {
        let alertController = UIAlertController(title: Text.more, message: nil, preferredStyle: .actionSheet)
        
        let editMarker = getEditAction()
        alertController.addAction(editMarker)
        
        let deleteMarker = getDeleteAction()
        alertController.addAction(deleteMarker)
        
        let cancel = UIAlertAction(title: Text.cancel, style: .cancel, handler: nil)
        alertController.addAction(cancel)
        
        delegate?.present(alertController, animated: true, completion: nil)
    }
    
    private func getEditAction() -> UIAlertAction {
        return UIAlertAction(title: "Edit", style: .default) { [weak self] (alert) in
            let presentVC = PSBaseViewController()
            if let markerEditView: PSMarkerEditView = PSMarkerEditView.fromNib() {
                if let marker = self?.marker {
                    markerEditView.prepareWithMarker(marker)
                    markerEditView.delegate = presentVC
                    markerEditView.frame = presentVC.view.frame
                    presentVC.view.addSubview(markerEditView)
                    self?.delegate?.reloadData()
                    self?.delegate?.navigationController?.pushViewController(presentVC, animated: true)
                }
            }
        }
    }
    
    private func getDeleteAction() -> UIAlertAction {
        return UIAlertAction(title: "Delete", style: .default) { [weak self] (alert) in
            guard let marker = self?.marker else {
                return
            }
            self?.delegate?.savedWithError(CoreDataHelper.deleteMarker(marker.id))
            self?.delegate?.reloadData()
        }

    }
}
