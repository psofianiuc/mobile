//
//  CustomUserDefaults.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 02/11/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import Foundation

struct UserDefaultsKeys {
    
}

class CustomUserDefaults: UserDefaults {
    static let shared: CustomUserDefaults = CustomUserDefaults()
    
    var userDefaults: UserDefaults {
        return UserDefaults.standard
    }
    
    // MARK: Private methods
    
    private func save(value: Any, forKey key: String) {
        userDefaults.set(value, forKey: key)
    }
    
    private func getObject(forKey key:String) -> Any? {
        return userDefaults.value(forKey: key)
    }
}
