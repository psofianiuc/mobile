//
//  Colors.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 20/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import Foundation
import UIKit


struct Colors {
    // White
    static let halfWhite = UIColor.init(white: 1, alpha: 0.5)
    // Red
    static let petal = UIColor(hexString: "f98866")
    static let poppy = UIColor(hexString: "ff420e")
    static let ripeApple = UIColor(hexString: "e73f0b")
    static let redDelicious = UIColor(hexString: "a11f0c")
    static let redDeliciousHalf = UIColor(hexString: "a11f0c", alpha: 0.5)
    static let strawberry = UIColor(hexString: "cb0000")
    static let strawberryHalf = UIColor(hexString: "cb0000", alpha: 0.5)
    // Green
    static let stem = UIColor(hexString: "80bd9e")
    static let springGreen = UIColor(hexString: "89da59")
    static let grannySmith = UIColor(hexString: "bbcf4a")
    static let basilGreen = UIColor(hexString: "3f6c45")
    // Yellow
    static let goldenDelicious = UIColor(hexString: "f4ec6a")
    static let lemonLime = UIColor(hexString: "e4ea8c")
    // Brown
    static let eggplant = UIColor(hexString: "50312f")
}
