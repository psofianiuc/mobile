//
//  FirebaseDatabaseHelper.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 02/11/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import Foundation
import Firebase
import FirebaseDatabase

class FirebaseDatabaseHelper {
    
    static var userReference: DatabaseReference?
    
    class func saveMarker(marker: Marker) {
        userReference = Database.database().reference()
        
        let markerValues = ["id": marker.id as Any,
                            "title": marker.title as Any,
                            "details": marker.details as Any,
                            "photo":  String(data: marker.photo! as Data, encoding: String.Encoding.utf8) as Any,
                            "altitude": marker.altitude as Any,
                            "longitude": marker.longitude as Any,
                            "latitude": marker.latitude as Any]
        
        userReference?.child("Markers").setValue(markerValues)
    }
    
    class func retrieveData() {
        
    }
    
    class func syncData() {
        
    }
}
