//
//  CoreDataHelper.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 17/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import UIKit
import CoreData

enum CoreDataErrors {
    case propertyError
    case internalError
    case markerNotExist
    case noError
}

class CoreDataHelper {
    
    class func getContext() -> NSManagedObjectContext? {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return nil
        }
        return appDelegate.persistentContainer.viewContext
    }
    
    class func saveMarker(_ title: String, _ details: String, _ long: Float?, _ lat: Float?, _ alt: Float?, _ image: Data, _ date: Date) -> CoreDataErrors {
        if title == "" || details == "" {
            return .propertyError
        }
        
        guard let lat = lat, let long = long, let alt = alt else {
            return .propertyError
        }
        
        
        guard let context = CoreDataHelper.getContext() else {
            return .internalError
        }
        
        let marker = Marker(context: context)
        
        marker.title = title
        marker.details = details
        marker.latitude = lat
        marker.longitude = long
        marker.altitude = alt
        marker.date = date as NSDate
        marker.photo = image as NSData
        marker.id = createIdFor(lat, long, alt, date)
        
        FirebaseDatabaseHelper.saveMarker(marker: marker)
        
        return save()
    }
    
    class func getSavedMarkers() -> [Marker] {
        let fetchRequest = NSFetchRequest<Marker>(entityName: "Marker")
        
        do {
            let result = try getContext()?.fetch(fetchRequest)
            return result ?? [Marker]()
        } catch {
            return [Marker]()
        }
    }
    
    class func updateMarker(_ id: Int64, _ title: String, _ details: String) -> CoreDataErrors {
        
        if title == "" || details == "" {
            return .propertyError
        }
        
        guard let marker = getMarker(id) else {
            return .markerNotExist
        }
        
        marker.title = title
        marker.details = details
        
        return save()
    }
    
    class func deleteMarker(_ id: Int64) -> CoreDataErrors {
        
        guard let marker = getMarker(id) else {
            return .markerNotExist
        }
        
        getContext()?.delete(marker)
        return save()
    }
    
    class func getMarker(_ id: Int64) -> Marker? {
        let fetchRequest = NSFetchRequest<Marker>(entityName: "Marker")
        print(fetchRequest)
        fetchRequest.predicate = NSPredicate(format: "id = %@", id.description)
        
        do {
            return try getContext()?.fetch(fetchRequest).first
        } catch {
            return nil
        }
    }
    
    // MARK: Private functions
    
    class private func save() -> CoreDataErrors {
        guard let context = getContext() else {
            return .internalError
        }
        
        do {
            try context.save()
            return .noError
        } catch {
            return .internalError
        }
    }
    
    class private func createIdFor(_ lat: Float, _ long: Float, _ alt: Float, _ date: Date) -> Int64 {
        let id = Int64(lat) + Int64(long) * 100 + Int64(alt) * 10000
        return Int64(date.timeIntervalSince1970) * 1000000 + id
    }
    
    class private func doesMarkerExist(_ long: String, _ lat: String, _ alt: String) -> Bool {
        let fetchRequest = NSFetchRequest<Marker>(entityName: "Marker")
        fetchRequest.predicate = NSPredicate(format: "latitude = %@ AND longitude = %@ AND altitude = %@", lat, long , alt)
        do {
            let result = try getContext()?.fetch(fetchRequest)
            return result!.count > 0
        } catch {
            return false
        }
    }
}

