//
//  Constants.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 14/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import Foundation
import UIKit

struct ButtonText {
    static let showMapMenu = "Menu"
    static let hideMapMenu = "Hide menu"
    static let goBackMapMenu = "Go back"
    static let stopTracking = "Stop tracking location"
    static let startTracking = "Start tracking location"
    
    static let optionNormal = "Normal"
    static let optionTerrain = "Terrain"
    static let optionSatellit = "Satellit"
    static let optionHybrid = "Hybrid"
    
    static let optionsMapStyleText = "Map style:"
    
    static let goBackCamera = "Go back"
    static let openCamera = "Open camera"
    static let saveLocation = "Save location"
    static let save = "Save"
    
    static let showMap = "Show map"
}

struct Text {
    static let more = "More"
    static let cancel = "Cancel"
    static let ok = "Ok"
}

struct Alert {
    static let error = "Error"
    static let success = "Success"
    static let markerNotExists = "Marker was not found."
    static let internalError = "An internal error has occured."
    static let propertyMissing = "Not all fields were field."
}

struct SegueNames {
    static let saveLocation = "saveLocationSegue"
}

struct Location {
    static let long = "longitude"
    static let alt = "altitude"
    static let lat = "latitude"
}

struct XibName {
    static let markerCollectionCell = "PSMarkerCollectionViewCell"
    static let markerDetailsView = "PSMarkerDetailsView"
    static let mainMapOverlay = "PSMainMapOverlayView"
    static let markerEditView = "PSMarkerEditView"
    
    // Storyboard
    static let mainStoryboardName = "Main"
}

struct Constants {
    static var aspectRatio: CGFloat {
        if UIDevice.current.hasSmallScreen() {
            return 1.549738
        } else if UIDevice.current.hasMediumScreen() {
            return 1.617511
        } else {
            return 1.657223
        }
        
    }
    
    static let dateFormat = "dd/MM/yyyy HH:mm"
}

struct CellIdentifier {
    static let markerCollectionCell = "markerCell"
}

class App {
    static func goToSettings() {
        guard let settingsUrl = URL(string: UIApplicationOpenSettingsURLString) else {
            return
        }
        
        if UIApplication.shared.canOpenURL(settingsUrl) {
            UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                print("Settings opened: \(success)")
            })
        }
    }
    
    class func getNotIplemtedAlert() -> UIAlertController {
        let alertController = UIAlertController(title: "Not implemented", message: "The feature is not implemnted yet.", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Ok", style: .cancel) { (alertAction) in
            
        }
        
        alertController.addAction(okAction)
        
        return alertController
    }
    
    class func getStringFromDate(_ date: NSDate?) -> String {
        guard let date = date else {
            return ""
        }
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = Constants.dateFormat
        return dateFormatter.string(from: date as Date)
    }
}
