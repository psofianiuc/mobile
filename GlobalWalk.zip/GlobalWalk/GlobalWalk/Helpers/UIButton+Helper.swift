//
//  UIButton+Helper.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 17/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import Foundation
import UIKit

extension UIButton {
    func prepareWhiteButtonUIWith(_ title: String) {
        self.setTitle(title, for: .normal)
        self.backgroundColor = UIColor(white: 1, alpha: 0.45)
        self.layer.cornerRadius = 7
        self.setTitleColor(.black, for: .normal)
    }
    
    func prepareRedButtonWith(_ title: String) {
        self.setTitle(title, for: .normal)
        self.setTitleColor(UIColor.white.withAlphaComponent(0.75), for: .normal)
        self.backgroundColor = Colors.redDelicious
        self.layer.cornerRadius = 7
    }
    
    func prepareGreenButtonWith(_ title:String) {
        self.setTitle(title, for: .normal)
        self.setTitleColor(UIColor.white.withAlphaComponent(0.75), for: .normal)
        self.backgroundColor = Colors.basilGreen
        self.layer.cornerRadius = 7
    }
}
