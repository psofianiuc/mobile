//
//  GUIHelper.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 02/11/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import Foundation
import UIKit
import FirebaseAuth

class GUIHelper: NSObject {
    // GUIHelper is a singleton
    static let shared = GUIHelper()
    
    func getRootViewController() -> UIViewController {
        if self.isLoggedIn() {
            // Show app
            return createMainStoryboard()
        } else {
            // Show login
            return createLoginViewController()
        }
    }
    
    private func isLoggedIn() -> Bool {
        if Auth.auth().currentUser != nil {
            return true
        }
        return false
    }
    
    private func createMainStoryboard() -> UIViewController {
        let mainStoryboard = UIStoryboard(name: XibName.mainStoryboardName, bundle: nil)
        return mainStoryboard.instantiateInitialViewController() ?? UIViewController()
    }
    
    private func createLoginViewController() -> UIViewController  {
        return PSLoginViewController.fromNib() as PSLoginViewController
    }
}
