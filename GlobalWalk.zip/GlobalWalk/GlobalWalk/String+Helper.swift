//
//  String+Helper.swift
//  GlobalWalk
//
//  Created by Paula Sofianiuc on 18/07/2017.
//  Copyright © 2017 Paula Sofianiuc. All rights reserved.
//

import Foundation

import UIKit

extension String {
    func length() -> Int {
        return self.characters.count
    }
    
    func substring(location:Int, length:Int) -> String! {
        return (self as NSString).substring(with: NSMakeRange(location, length))
    }
    
    subscript(index: Int) -> String! {
        get {
            return self.substring(location: index, length: 1)
        }
    }
    
    func location(other: String) -> Int {
        return (self as NSString).range(of: other).location
    }
    
    func contains(other: String) -> Bool {
        return (self as NSString).contains(other)
    }
    
    func localized() -> String {
        var preferredLanguage = ""
        if Bundle.main.preferredLocalizations.count > 0 {
            preferredLanguage = Bundle.main.preferredLocalizations.first!
        } else {
            preferredLanguage = "en"
        }
        
        let baseLanguage = "Base"
        
        if let path = Bundle.main.path(forResource: preferredLanguage, ofType: "lproj"), let bundle = Bundle(path: path) {
            return bundle.localizedString(forKey: self, value: nil, table: nil)
        }
        else if let path = Bundle.main.path(forResource: baseLanguage, ofType: "lproj"), let bundle = Bundle(path: path) {
            return bundle.localizedString(forKey: self, value: nil, table: nil)
        }
        return self
    }
}
